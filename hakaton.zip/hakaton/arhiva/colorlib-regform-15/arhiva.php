<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Arhiviranje</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link href="zoom.css" rel="stylesheet">
    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="main">
        <div class="container">
            <div class="signup-content">
                <div class="signup-img">
                    <img src="images/signup-img.jpg" alt="">
                </div>
                
                <div class="signup-form">
                <a href="../../123/posao.php"><img src ="images/close.png" class="poz"height=20px width=20px align="right"></a>
                    <form method="POST" class="register-form" id="register-form" action="../../123/posao.php">
                       <h2>REGISTRACIJA ZA ARHIVIRANJE STARIH SPISA</h2> 
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">Ime :</label>
                                <input type="text" name="name" id="name" required/>
                            </div>
                            <div class="form-group">
                                <label for="father_name">Prezime :</label>
                                <input type="text" name="father_name" id="father_name" required/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="address">Broj licne karte/Pasosa :</label>
                            <input type="text" name="pincode" id="pincode" required/>
                        </div>
                        <div class="form-radio">
                            <label for="gender" class="radio-label">Pol :</label>
                            <div class="form-radio-item">
                                <input type="radio" name="gender" id="male" checked>
                                <label for="male">M</label>
                                <span class="check"></span>
                            </div>
                            <div class="form-radio-item">
                                <input type="radio" name="gender" id="female">
                                <label for="female">Z</label>
                                <span class="check"></span>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="state">Zemlja :</label>
                                <div class="form-select">
                                    <select name="state" id="state">
                                        <option value=""></option>
                                        <option value="srb">Srbija</option>
                                        <option value="cg">Crna Gora</option>
                                        <option value="hrv">Hrvatska </option>
                                        <option value="bih">Bosna i Heregovina</option>
                                        <option value="mkd">Severna Makedonija</option>
                                    </select>
                                    <span class="select-icon"><i class="zmdi zmdi-chevron-down"></i></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="city">Grad :</label>
                                <div class="form-select">
                                    <select name="city" id="city">
                                        <option value=""></option>
                                        <option value="beograd">Beograd</option>
                                        <option value="novisad">Novi Sad</option>
                                        <option value="nis">Nis</option>
                                        <option value="kraljevo">Kraljevo</option>
                                        <option value="subotica">Subotica</option>
                                        <option value="kragujevac">Kragujevac</option>
                                        <option value="cacak">Cacak</option>
                                        <option value="ostalo">OSTALO</option>



                                    </select>
                                    <span class="select-icon"><i class="zmdi zmdi-chevron-down"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email">Upisite grad/selo/naselje(ukoliko ste gore odabrali ostalo):</label>
                            <input type="text" name="ostatak" id="ostatak" />
                        </div>
                        
                        <div class="form-group">
                            <label for="birth_date">Postanski broj :</label>
                            <input type="text" name="postanski" id="postanski">
                        </div>
                        <div class="form-group">
                            <label for="pincode">Adresa :</label>
                            <input type="text" name="adress" id="adress">
                        </div>
                        <div class="form-group">
                            <label for="course">Posao :</label>
                            <div class="form-select">
                                <select name="course" id="course">
                                    <option value=""></option>
                                    <option value="computer">Arhiviranje narodne biblioteke</option>
                                    <option value="desiger">Arhiviranje privatnih spisa</option>
                                    <option value="marketing">Arhiviranje muzeja</option>
                                </select>
                                <span class="select-icon"><i class="zmdi zmdi-chevron-down"></i></span>
                            </div>
                        </div>

                        <div class="form-submit">
                            <input type="submit" value="Reset All" class="submit" name="reset" id="reset" />
                            <input onclick="myFunction()" type="submit" value="Submit Form" class="submit" name="submit" id="submit" />
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
    <script>
       
        function myFunction() {
            
         
  alert("Podaci poslati");
            
        }
            </script>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>