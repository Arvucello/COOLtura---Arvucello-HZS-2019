<?php
require('konekcija.php');
$fullname = $_POST['name'];
$k_ime = $_POST['username'];
$lozinka = $_POST['pass'];
$mail = $_POST['email'];   
$query = "SELECT * FROM users WHERE (username = '$k_ime')";
$query2 = "SELECT * FROM users WHERE (email = '$mail')";
$result = mysqli_query($Veza,$query);
$count = mysqli_num_rows($result);
$result2 = mysqli_query($Veza, $query2);
$count2 = mysqli_num_rows($result2);
if($count > 0)
    {
        echo "Vec postoji korisnik sa datim korisnickim imenom.";
    }
else if($count2 > 0)
{
    echo "Vec postoji korisnik sa datim email-om.";
}
else
{
    $stavi = "INSERT INTO users (fullname, email, username, sifra)
    VALUES ('$fullname', '$mail', '$k_ime', '$lozinka')";
    if(mysqli_query($Veza, $stavi))
        header("Location: login.php");
    else echo "Greska.";
    mysqli_close($Veza);
}
?>