<?php
require('konekcija.php');
$k_ime = $_POST['username'];
$lozinka = $_POST['pass'];   
$query = "SELECT * FROM users WHERE (username = '$k_ime' AND sifra = '$lozinka')";
$result = mysqli_query($Veza,$query);
$count = mysqli_num_rows($result);
if($count > 0) {
header("Location: ../123/main.php");
        }
        else {
            echo "login neuspesan. Molimo pokusajte ponovo.";
            echo "<a href='login.php'>POKUSAJ PONOVO</a>" ;
        }
        mysqli_close($Veza);
?>