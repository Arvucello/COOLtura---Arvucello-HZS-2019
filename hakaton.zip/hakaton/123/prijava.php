<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>COOLtura - Proširi Svoje Vidike</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href ="zoom.css" rel="stylesheet">
  <link href ="stilovi.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body style = "background-color: #00ffa3;">

<script class="jsbin" src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<div class="file-upload">
  <button class="file-upload-btn" type="button" onclick="$('.file-upload-input').trigger( 'click' )">Add Image</button>

  <div class="image-upload-wrap">
    <input class="file-upload-input" type='file' onchange="readURL(this);" accept="image/*" />
    <div class="drag-text">
      <h3>Drag and drop a file or select add Image</h3>
    </div>
  </div>
  <div class="file-upload-content">
    <img class="file-upload-image" src="#" alt="your image" />
    <div class="image-title-wrap">
      <button type="button" onclick="removeUpload()" class="remove-image">Remove <span class="image-title">Uploaded Image</span></button>
    </div>
  </div>
<div class="container">  
  <form id="contact" action="contest.php" method="post">
    <fieldset>
      <input placeholder="Naslov" type="text" tabindex="1" required autofocus>
    </fieldset>
      <input placeholder="Opis slike" type="text" tabindex="3" required>
    </fieldset>
    <fieldset>
      <input placeholder="Datum" type="text" tabindex="4" required>
    </fieldset>
    <fieldset>
      <button name="submit" type="submit" id="contact-submit" data-submit="...Sending" onclick="myFunction()">Postavi</button>
    </fieldset>
    </form>
    </div>

  

    <script>
       
       function myFunction() {
           
        
        alert("Podaci poslati");
           
       }
           </script>
<script src="postavi.js"></script>
</body>
</html>