!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>COOLtura - Proširi Svoje Vidike</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
</head>

<body style = "background-color: #00ffa3;">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#" style = "font-size: 200%;">COOLtura</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="main.php">Početna

            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="onama.html">O nama</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="contest.php">Contest</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="dodaj.php">Dodaj događaj</a>
              </li>
              <li class="nav-item">
            <a class="nav-link" href="posao.php">Zaposli se</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="forum.php">Forum <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../Login_v13/login.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <h1 style = "font-size: 200%; text-align: center;">FORUM - CHAT</h1>
    <p ><h3 class="4"style= "text-align:center";>Ovde možete da se dodatno raspitate i informišete o svim informacijama, uz razgovor sa drugim korisnicima sajta.<h3></p>
    <div style = "background-color: white; width: 75%; height: 60%; border: solid black 2px; border-radius: 5px; margin: 0 auto;"><p id = "messagebox" style = "font-size: 100%;"></p>
  </div>
  <form method = "POST" action = "saljiporuku.php">
    <input type = "text" name = "ime" id = "ime" placeholder = "Unesite ime" maxlength = "30" style = "width: 20%; margin-top: 30px; margin-left: 230px; border: solid black 2px;"></input>
    <input type = "text" name = "poruka" id = "poruka"  placeholder = "Unesite poruku" maxlength = "100" style = "width: 76%; margin-top: 10px; margin-left: 230px; border: solid black 2px;"></input>
	<button type = "submit" id = "submit" name = "submit" class = "btn btn-primary" onclick = "postavi()" style = "display: block; margin-left: 48%; margin-top: 1%;">Pošalji poruku</button>
  </form>
	<script>
	
	setInterval(postavi, 500);
	function postavi()
{
	var xhr = new XMLHttpRequest();
	
	xhr.onreadystatechange = function()
	{
		if(this.readyState == 4 && this.status == 200)
		{
			document.getElementById("messagebox").innerHTML = this.responseText;
		}
	}
	xhr.open("GET", "obrada.php", true);
	xhr.send();
}
  </script>
   <div class="col-lg-3 col-md-6 mb-4">
      <button style = "display: inline-block; background-color: #00ffa3; width: 1%; height: 15px;" onclick = "zelena()"></button>
       <button style = "display: inline-block; background-color: #FF5555; width: 1%; height: 15px;" onclick = "crvena()"></button>
       <button style = "display: inline-block; background-color: lightblue; width: 1%; height: 15px;" onclick = "plava()"></button>
      <br>
       <button style = "display: inline-block; background-color: orange; width: 1%; height: 15px;" onclick = "orange()"></button>
        <button style = "display: inline-block; background-color: darkgreen; width: 1%; height: 15px;" onclick = "darkgreen()"></button>
        <button style = "display: inline-block; background-color: gray; width: 1%; height: 15px;" onclick = "gray()"></button>
      </div>
        <script>
          function zelena()
          {
              document.body.style.backgroundColor = "#00ffa3";
               document.getElementByClass("4").style.color = "black";
          }
          function crvena()
          {
              document.body.style.backgroundColor = "#410727";
               document.getElementById("4").style.color = "white";
          }
          function plava()
          {
              document.body.style.backgroundColor = "lightblue";
               document.getElementById("4").style.color = "black";
          }
          function orange()
          {
              document.body.style.backgroundColor = "orange";
               document.getElementById("4").style.color = "white";              
          }
          function darkgreen()
          {
              document.body.style.backgroundColor = "darkgreen";
               document.getElementById("4").style.color = "white";
          }
          function gray()
          {
              document.body.style.backgroundColor = "gray";
               document.getElementById("4").style.color = "white";
          }
      </script>
</body>
</html>