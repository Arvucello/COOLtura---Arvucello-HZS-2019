<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>COOLtura - Proširi Svoje Vidike</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="zoom.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body style = "background-color: #00ffa3;">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container" id="1">
      <a class="navbar-brand" href="#" style = "font-size: 200%;">COOLtura</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item ">
            <a class="nav-link" href="main.php">Početna
            
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="onama.html">O nama</a>
          </li>
          <li class="nav-item active">
              <a class="nav-link" href="contest.php">Contest  <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="dodaj.php">Dodaj događaj</a>
              </li>
              <li class="nav-item">
            <a class="nav-link" href="posao.php">Zaposli se</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="forum.php">Forum</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../Login_v13/login.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container" style =  "margin-top: 50px;">

    <!-- Jumbotron Header -->
    <header class="jumbotron my-4" style = "padding: 30px;">
      <h1 class="display-3" style = "text-align: center;">COOLtura takmičenje!</h1> <br> <br>
      <p class="lead" style = "text-align: center;">Dobrodošli na najneobičnije takmičenje.<br><br>COOLtura takmičenje je takmičenje na kome se mogu osvojiti vredne kulturne nagrade, kao i privući pažnja, ne samo ka Vama kao umetniku, nego i ka Vašem okruženju.<br>
      Tako što pored vrednih vaučera i karata za bioskope, pozorišta, muzeje i ostale kultne ustanove pobednička slika dobija i šansu da bude izvučena u igri "Cooltura-loto" koja se održsva svakog 4. u mesecu .<br>
      Izvučena loptica sa imenom nekog od pobedničkih naselja sa slike biće destinacija izleta mnogih škola, u tom mesecu.<br>
     Prijavi se i ti i osvoji vredne nagrade <br> <br>
      <a href="prijava.php" class="btn btn-primary">Prijavi se!</a>
    </p>
    </header>
    <div id="vreme" style = "width: 100%; height: 200px; margin-left: 00px; background-color: #00ffa3;">
		<div id = "dani" style = "width: 20%; height: 100%; background-color: lightgray; display: inline-block; margin-left: 100px; font-size: 100px; text-align: center; border: solid black 5px; border-radius: 25px;">1</div>
		<div id = "sati" style = "width: 20%; height: 100%; background-color: lightgray; display: inline-block; font-size: 100px; text-align: center; border: solid black 5px; border-radius: 25px;">1</div>
		<div id = "minuti" style = "width: 20%; height: 100%; background-color: lightgray; display: inline-block; font-size: 100px; text-align: center; border: solid black 5px; border-radius: 25px;">1</div>
		<div id = "sekunde" style = "width: 20%; height: 100%; background-color: lightgray; display: inline-block; font-size: 100px; text-align: center; border: solid black 5px; border-radius: 25px;">1</div>
		<br><p style = "display: inline-block; margin-left: 15%; font-size: 200%;"></p><p style = "display: inline-block; margin-left: 15%; font-size: 200%;"></p>
		<p style = "display: inline-block; margin-left: 15%; font-size: 200%"></p><p style = "display: inline-block; margin-left: 10%; font-size: 200%"><p><h3 id="2" style= "text-align:center";>DO KRAJA MESECNOG TAKMIČЕNjA</h3></p><br><br>
	</div><br><br><br>
	<script>
	setInterval(funkcija, 1000);
	function funkcija()
	{
		var d = new Date();
		var dani = d.getDate();
		var sati = d.getHours();
		var minuti = d.getMinutes();
		var sekunde = d.getSeconds();
		
		document.getElementById("sekunde").innerHTML = (60 - sekunde - 1).toString();
		document.getElementById("minuti").innerHTML = (60 - minuti - 1).toString();
		document.getElementById("sati").innerHTML = (24 - sati - 1).toString();
		document.getElementById("dani").innerHTML = (30 - dani).toString();
	}
  </script>
  <br><br><br>
  <h1 id="3" class="display-3" style = "text-align: center; font-size: 300%; margin-bottom: 20px; margin-top: -10px;">Trenutno takmičenje:</h1>
    <!-- Page Features -->
    <div class="row text-center">

      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s11.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Slankamen </h4>
            <p class="card-text">Oj Dunave moj<br> Datum:24.11.2019<br>
          Mileva Savić</p>
          </div>
          <div class="card-footer">
            <a ><h4>**********</h4></a>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s6.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Suncokret</h4>
            <p class="card-text">Prelepo<br> Datum: 23.11.2019<br>
          Milenko Topić</p>
          </div>
          <div class="card-footer">
            <a ><h4>**********</h4></a>
          </div>
        </div>
      </div>



      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s7.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Banjska stena</h4>
            <p class="card-text">Bosna i Srbija zauvek! <br> Datum: 21.11.2019<br>
          Filip Čubrić</p>
          </div>
          <div class="card-footer">
            <a ><h4>*********</h4></a>
          </div>
        </div>
      </div>
<div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s9.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Kragujevac</h4>
            <p class="card-text">Lep sunčan dan <br> Datum: 10.11.2019<br>
          Andrija Mojović</p>
          </div>
          <div class="card-footer">
            <a ><h4>*********</h4></a>
          </div>
        </div>
      </div>
      

    </div>
    <!-- /.row -->
    <div class="row text-center">

      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s8.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Kopaonik </h4>
            <p class="card-text">Hop na Kop<br> Datum:16.11.2019<br>
          Ana Ristić</p>
          </div>
          <div class="card-footer">
            <a ><h4>*********</h4></a>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s10.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Zemun</h4>
            <p class="card-text">Munze konza<br> Datum: 09.11.2019<br>
          Milenko Bubalo</p>
          </div>
          <div class="card-footer">
            <a ><h4>********</h4></a>
          </div>
        </div>
      </div>



      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s5.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Brzam</h4>
            <p class="card-text">Pobednički pejzaš <br> Datum: 17.11.2019<br>
          Filip Andrić</p>
          </div>
          <div class="card-footer">
            <a ><h4>*******</h4></a>
          </div>
        </div>
      </div>
<div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s12.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Ohrid</h4>
            <p class="card-text">Jezerce <br> Datum: 25.11.2019<br>
          Aleksa Nin</p>
          </div>
          <div class="card-footer">
            <a ><h4>******</h4></a>
          </div>
        </div>
      </div>
      

    </div>
    <div class="row text-center">

      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s1.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Exit </h4>
            <p class="card-text">Svirka, zezanje i dobra fotka<br> Datum:11.11.2019<br>
          Branko Milošević</p>
          </div>
          <div class="card-footer">
            <a ><h4>****</h4></a>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s2.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">BG noću</h4>
            <p class="card-text">Lepota<br> Datum: 04.11.2019<br>
          Milenko Topić</p>
          </div>
          <div class="card-footer">
            <a ><h4>***</h4></a>
          </div>
        </div>
      </div>



      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s3.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Kraljevo</h4>
            <p class="card-text">Najlepše mesto u Krljevu <br> Datum: 16.11.2019<br>
          Filip Čubrić</p>
          </div>
          <div class="card-footer">
            <a ><h4>***</h4></a>
          </div>
        </div>
      </div>
<div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="s4.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Niš</h4>
            <p class="card-text">Šni <br> Datum: 12.11.2019<br>
          Aleksa Nedić</p>
          </div>
          <div class="card-footer">
            <a ><h4>**</h4></a>
          </div>
        </div>
      </div>
</div>
      <div class="card-footer">
            <a href="nagrade.php" class="btn btn-primary" width="100%" style="text-align: center; margin-left:40%">POGLEDAJ NAGRADE!</a>
          </div>
    </div>

  
  <div class="col-lg-3 col-md-6 mb-4">
      <button style = "display: inline-block; background-color: #00ffa3; width: 1%; height: 15px;" onclick = "zelena()"></button>
       <button style = "display: inline-block; background-color: #FF5555; width: 1%; height: 15px;" onclick = "crvena()"></button>
       <button style = "display: inline-block; background-color: lightblue; width: 1%; height: 15px;" onclick = "plava()"></button>
      <br>
       <button style = "display: inline-block; background-color: orange; width: 1%; height: 15px;" onclick = "orange()"></button>
        <button style = "display: inline-block; background-color: darkgreen; width: 1%; height: 15px;" onclick = "darkgreen()"></button>
        <button style = "display: inline-block; background-color: gray; width: 1%; height: 15px;" onclick = "gray()"></button>
      </div>
      <script>
          function zelena()
          {
              document.body.style.backgroundColor = "#00ffa3";
              document.getElementById("vreme").style.backgroundColor = "#00ffa3";
              document.getElementById("2").style.color = "black";
               document.getElementById("3").style.color = "black";
          }
          function crvena()
          {
              document.body.style.backgroundColor = "#410727";
               document.getElementById("vreme").style.backgroundColor = "#410727";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function plava()
          {
              document.body.style.backgroundColor = "lightblue";
               document.getElementById("vreme").style.backgroundColor = "lightblue";
               document.getElementById("2").style.color = "black";
               document.getElementById("3").style.color = "black";
          }
          function orange()
          {
              document.body.style.backgroundColor = "orange";
               document.getElementById("vreme").style.backgroundColor = "orange";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function darkgreen()
          {
              document.body.style.backgroundColor = "darkgreen";
               document.getElementById("vreme").style.backgroundColor = "darkgreen";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function gray()
          {
              document.body.style.backgroundColor = "gray";
               document.getElementById("vreme").style.backgroundColor = "gray";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
      </script>
  <!-- /.container -->

  <!-- Footer -->


  <!-- Bootstrap core JavaScript -->
  <script src="postavi.js"></script>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
