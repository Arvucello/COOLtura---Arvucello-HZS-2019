<?php
include_once('konekcija.php');
$Upit2 = "SELECT * FROM poruke ORDER BY id DESC LIMIT 10";
$Rezultat = mysqli_query($Veza, $Upit2);
$Ispis = "";
while($Red = mysqli_fetch_assoc($Rezultat))
{
	$Ispis .= $Red['ime'] . ": " . $Red['poruka'] . "<br>";
}
echo $Ispis;
?>