<?php
include_once('konekcija.php');
if(isset($_POST['submit'])){
$ime = date("d.m.Y.") .  " u " . date("h:ia") . " - " . $_POST['ime'];
$poruka = $_POST['poruka'];
$Upit = "INSERT INTO poruke(ime, poruka) VALUES('$ime', '$poruka')";
if($run = $Veza->query($Upit))
	header("Location: forum.php");
}
?>