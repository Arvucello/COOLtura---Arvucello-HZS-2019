!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>COOLtura - Proširi Svoje Vidike</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body style = "background-color: #00ffa3;">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="main.php" style = "font-size: 200%;">COOLtura</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="main.php">Početna </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="onama.html">O nama </a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="contest.php">Contest</a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="dodaj.php">Dodaj događaj</a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="posao.php">Zaposli se<span class="sr-only">(current)</span></a>
              </li>
          <li class="nav-item">
            <a class="nav-link" href="forum.php">Forum</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../Login_v13/login.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container" style =  "margin-top: 50px;">

  <header class="jumbotron my-4" style = "padding: 30px;">
    <h1 class="display-3" style = "text-align: center;">Digitalno arhiviranje starih spisa</h1><br>
    <p class="lead" style = "text-align: center;">Jedan od naših ciljeva je očuvanje kulturnog dobra Srbije, za naredna pokoljenja. Među prioritetima nalazi se očuvanje starih knjiga, istorijskih spisa i ostale arhivske građe, njihova digitalizacija i dostupnost u elektronskoj formi, kao nadolazećem, sve dominantnijem načinu upoznavanja mlađih generacija sa kulturnim nasleđem.<br> <br>
Kako bi se uz to i zadržao veći broj mladih u našoj zemlji, inače sve ovo što radimo i nema veliku budućnost, došli smo do ideje da nam se u ovom postupku pridruži što veći broj drugova. Time pozivamo i tebe da se prijaviš za skeniranje dokumentacije iz biblioteka i arhiva širom Srbije. Pored upoznavanja sa našim kulturnim blagom, steći ćeš mogućnost da prisustvuješ kulturnim događajima u glavnom i ostalim većim gradovima Srbije, bez obzira na tvoje mesto boravka! <br><br>

U saradnji sa kompanijama, ministarstvima i lokalnim samoupravama, biće organizovan prevoz, smeštaj i ulaznice za koncerte, festivale, pozorišne predstave, izložbe, sajmove i promocije knjiga, kao nagrada za volonterski rad i potrošeno vreme. Budi i ti deo uspešnog projekta kojim ćeš moći da se pohvališ u društvu i pred svojom decom jednog dana. <br>
Postani i ti deo Tima Arvucello odmah:<br><br>     
            <a href="../arhiva/colorlib-regform-15/arhiva.php" class="btn btn-primary">Prijavi se!</a>
          
<br><br><br>
      Možete nas kontaktirati preko:<br>
      E-mail: arvucello@gmail.com<br>
      Phone: 0616324573
      
    </p>
  </header>

  </div>
  <div class="col-lg-3 col-md-6 mb-4">
      <button style = "display: inline-block; background-color: #00ffa3; width: 1%; height: 15px;" onclick = "zelena()"></button>
       <button style = "display: inline-block; background-color: #FF5555; width: 1%; height: 15px;" onclick = "crvena()"></button>
       <button style = "display: inline-block; background-color: lightblue; width: 1%; height: 15px;" onclick = "plava()"></button>
      <br>
       <button style = "display: inline-block; background-color: orange; width: 1%; height: 15px;" onclick = "orange()"></button>
        <button style = "display: inline-block; background-color: darkgreen; width: 1%; height: 15px;" onclick = "darkgreen()"></button>
        <button style = "display: inline-block; background-color: gray; width: 1%; height: 15px;" onclick = "gray()"></button>
      </div>
  <script>
          function zelena()
          {
              document.body.style.backgroundColor = "#00ffa3";
              document.getElementById("vreme").style.backgroundColor = "#00ffa3";
              document.getElementById("2").style.color = "black";
               document.getElementById("3").style.color = "black";
          }
          function crvena()
          {
              document.body.style.backgroundColor = "#410727";
               document.getElementById("vreme").style.backgroundColor = "#410727";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function plava()
          {
              document.body.style.backgroundColor = "lightblue";
               document.getElementById("vreme").style.backgroundColor = "lightblue";
               document.getElementById("2").style.color = "black";
               document.getElementById("3").style.color = "black";
          }
          function orange()
          {
              document.body.style.backgroundColor = "orange";
               document.getElementById("vreme").style.backgroundColor = "orange";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function darkgreen()
          {
              document.body.style.backgroundColor = "darkgreen";
               document.getElementById("vreme").style.backgroundColor = "darkgreen";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function gray()
          {
              document.body.style.backgroundColor = "gray";
               document.getElementById("vreme").style.backgroundColor = "gray";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
      </script>
</body>
</html>
