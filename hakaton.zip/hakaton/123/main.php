<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>COOLtura - Proširi Svoje Vidike</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="zoom.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">
  <style>
* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
</style>
</head>

<body style = "background-color: #00ffa3;">

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#" style = "font-size: 200%;">COOLtura</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="main.php">Početna
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="onama.html">O nama</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="contest.php">Contest</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="dodaj.php">Dodaj događaj</a>
              </li>
              <li class="nav-item">
            <a class="nav-link" href="posao.php">Zaposli se</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="forum.php">Forum</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../Login_v13/login.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

 
  <div class="container" style =  "margin-top: 50px;">

    
    <header class="jumbotron my-4" style = "padding: 30px;">
      <h1 class="display-3" style = "text-align: center;">Dobrodošli!</h1>
      <p class="lead" style = "text-align: center;">COOLtura je mesto na kome se možete informisati, prijaviti i otkriti sva kulturna dešavanja u Vašem okruženju.<br>
      Naša mesečna takmičenja Vam omogućavaju da, uz proširivanje Vaših kulturnih vidika, osvojite i vredne nagrade.</p>
    </header>
    <h1 id="4" class="display-3" style = "text-align: center; font-size: 300%; margin-bottom: 20px; margin-top: -10px;">Predstojeći događaji:</h1>
    
    <div class="row text-center">

      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="1.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Izložba savremene umetnosti </h4>
            <p class="card-text">Galerija savremene umetnosti u Nišu Vam predstavlja novu izložbu povodom jubileja galerije<br> Datum:28.11.2019</p>
          </div>
          <div class="card-footer">
            <a href="https://www.gslunis.org/" class="btn btn-primary">Prijavi se!</a>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="2.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Radionice italijanskog jezika</h4>
            <p class="card-text">Prijavite se za radionice italijanskog jezika u Kulturnom centru u Novom Sadu<br> Datum: 01.12.2019</p>
          </div>
          <div class="card-footer">
            <a href="https://www.kcns.org.rs/" class="btn btn-primary">Prijavi se!</a>
          </div>
        </div>
      </div>



      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom"  class="card h-100">
          <img class="card-img-top" src="4.jpg" alt="" style = "height: 150px;  ">
          <div class="card-body">
            <h4 class="card-title">Premijera predstave ,,Onjegin"</h4>
            <p class="card-text">Narodno pozorište u Beogradu Vam predstavlja novu predstavu ,,Onjegin" <br> Datum: 13.12.2019</p>
          </div>
          <div class="card-footer">
            <a href="https://www.narodnopozoriste.rs/" class="btn btn-primary">Prijavi se!</a>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 mb-4">
        <div id="zoom" class="card h-100">
          <a href="dodaj.php"><img class= "card-img-top"src="img/+.png" alt="" style = "height: 150px;" width="200"></a>
          <div class="card-body">
            <h4 class="card-title">Dodaj sopstveni dogadjaj</h4>
            <p class="card-text">Dobrodošli ste da date predlog o dodavanju Vama kulturološki značajnog događaja</p>
          </div>
          <div class="card-footer">
            <a href="dodaj.php" class="btn btn-primary">Dodaj!</a>
          </div>
        </div>
      </div>
      

    </div>
    <!-- /.row -->
<br><br>
  </div>
  <!-- /.container -->
  <div class="col-lg-3 col-md-6 mb-4">
      <button style = "display: inline-block; background-color: #00ffa3; width: 1%; height: 15px;" onclick = "zelena()"></button>
       <button style = "display: inline-block; background-color: #FF5555; width: 1%; height: 15px;" onclick = "crvena()"></button>
       <button style = "display: inline-block; background-color: lightblue; width: 1%; height: 15px;" onclick = "plava()"></button>
      <br>
       <button style = "display: inline-block; background-color: orange; width: 1%; height: 15px;" onclick = "orange()"></button>
        <button style = "display: inline-block; background-color: darkgreen; width: 1%; height: 15px;" onclick = "darkgreen()"></button>
        <button style = "display: inline-block; background-color: gray; width: 1%; height: 15px;" onclick = "gray()"></button>
      </div>
<script>
          function zelena()
          {
              document.body.style.backgroundColor = "#00ffa3";
              document.getElementById("vreme").style.backgroundColor = "#00ffa3";
              document.getElementById("4").style.color = "black";
               document.getElementById("3").style.color = "black";
          }
          function crvena()
          {
              document.body.style.backgroundColor = "#410727";
               document.getElementById("vreme").style.backgroundColor = "#410727";
               document.getElementById("4").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function plava()
          {
              document.body.style.backgroundColor = "lightblue";
               document.getElementById("vreme").style.backgroundColor = "lightblue";
               document.getElementById("4").style.color = "black";
               document.getElementById("3").style.color = "black";
          }
          function orange()
          {
              document.body.style.backgroundColor = "orange";
               document.getElementById("vreme").style.backgroundColor = "orange";
               document.getElementById("4").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function darkgreen()
          {
              document.body.style.backgroundColor = "darkgreen";
               document.getElementById("vreme").style.backgroundColor = "darkgreen";
               document.getElementById("4").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function gray()
          {
              document.body.style.backgroundColor = "gray";
               document.getElementById("vreme").style.backgroundColor = "gray";
               document.getElementById("4").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
      </script>
      <p style = "font-size: 200%; text-align: center;">Informišite se o vremenu pre izlaska!</p>
<a class="weatherwidget-io" href="https://forecast7.com/en/44d7920d45/belgrade/" data-label_1="BELGRADE" data-label_2="WEATHER" data-theme="original" >BELGRADE WEATHER</a>
<script>
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
</script>
<a class="weatherwidget-io" href="https://forecast7.com/en/45d2719d83/novi-sad/" data-label_1="NOVI SAD" data-label_2="WEATHER" data-theme="original" >NOVI SAD WEATHER</a>
<script>
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
</script>
<a class="weatherwidget-io" href="https://forecast7.com/en/43d3221d90/nis/" data-label_1="NIŠ" data-label_2="WEATHER" data-theme="original" >NIŠ WEATHER</a>
<script>
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
</script>
  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Arvucello 2019</p>
    </div>
    <!-- /.container -->
    
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
