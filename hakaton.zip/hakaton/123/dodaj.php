<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>COOLtura - Proširi Svoje Vidike</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href ="stilovi.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body style = "background-color: #00ffa3;">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#" style = "font-size: 200%;">COOLtura</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="main.php">Početna
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="onama.html">O nama</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="contest.php">Contest</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="dodaj.php">Dodaj događaj
                <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
            <a class="nav-link" href="posao.php">Zaposli se</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="forum.php">Forum</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../Login_v13/login.php">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>


  <div class="container">  
  <form id="contact" action="ContactFrom_v1/ContactFrom_v1/mail.php" method="post">
    <h3>Predložite svoj događaj</h3>
    <fieldset>
      <input placeholder="Ime događaja" type="text" tabindex="1" required autofocus>
    </fieldset>
    <fieldset>
      <input placeholder="Opis događaja" type="text" tabindex="2" required>
    </fieldset>
    <fieldset>
      <input placeholder="Mesto događaja" type="text" tabindex="3" required>
    </fieldset>
    <fieldset>
      <input placeholder="Datum" type="text" tabindex="4" required>
    </fieldset>
    <fieldset>
    <input placeholder="Vreme" type="text" tabindex="4" required>
    </fieldset>
    <fieldset>
      <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Submit</button>
    </fieldset>
   
  </form>
</div>
<div class="col-lg-3 col-md-6 mb-4">
      <button style = "display: inline-block; background-color: #00ffa3; width: 1%; height: 15px;" onclick = "zelena()"></button>
       <button style = "display: inline-block; background-color: #FF5555; width: 1%; height: 15px;" onclick = "crvena()"></button>
       <button style = "display: inline-block; background-color: lightblue; width: 1%; height: 15px;" onclick = "plava()"></button>
      <br>
       <button style = "display: inline-block; background-color: orange; width: 1%; height: 15px;" onclick = "orange()"></button>
        <button style = "display: inline-block; background-color: darkgreen; width: 1%; height: 15px;" onclick = "darkgreen()"></button>
        <button style = "display: inline-block; background-color: gray; width: 1%; height: 15px;" onclick = "gray()"></button>
      </div>
<script>
          function zelena()
          {
              document.body.style.backgroundColor = "#00ffa3";
              document.getElementById("vreme").style.backgroundColor = "#00ffa3";
              document.getElementById("2").style.color = "black";
               document.getElementById("3").style.color = "black";
          }
          function crvena()
          {
              document.body.style.backgroundColor = "#410727";
               document.getElementById("vreme").style.backgroundColor = "#410727";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function plava()
          {
              document.body.style.backgroundColor = "lightblue";
               document.getElementById("vreme").style.backgroundColor = "lightblue";
               document.getElementById("2").style.color = "black";
               document.getElementById("3").style.color = "black";
          }
          function orange()
          {
              document.body.style.backgroundColor = "orange";
               document.getElementById("vreme").style.backgroundColor = "orange";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function darkgreen()
          {
              document.body.style.backgroundColor = "darkgreen";
               document.getElementById("vreme").style.backgroundColor = "darkgreen";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
          function gray()
          {
              document.body.style.backgroundColor = "gray";
               document.getElementById("vreme").style.backgroundColor = "gray";
               document.getElementById("2").style.color = "white";
               document.getElementById("3").style.color = "white";
          }
      </script>
</body>
</html>